import 'scripts/gametests/{{FILE_NAME}}.{{LANGUAGE}}'
